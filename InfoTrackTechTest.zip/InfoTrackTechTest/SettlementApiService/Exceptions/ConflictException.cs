﻿namespace SettlementApiService.Exceptions
{
    public class ConflictException : Exception
    {
    }
}
