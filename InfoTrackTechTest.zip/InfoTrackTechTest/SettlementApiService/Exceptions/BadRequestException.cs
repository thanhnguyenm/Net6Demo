﻿namespace SettlementApiService.Exceptions
{
    public class BadRequestException : Exception
    {
    }
}
